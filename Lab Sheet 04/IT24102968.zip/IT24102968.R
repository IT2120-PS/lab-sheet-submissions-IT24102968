setwd("C:\\Users\\IT24102968\\Desktop\\IT24102968\\IT24102968")
data <- read.csv("Exercise.txt", header = TRUE,sep = "\t")

Input Team1 data as a vector
Team1 <- c(3.361, 59.536, 2.288, 49.518, 35, 3.914, 1.716, 34.370, 28, 
           1.750, 33.434, 12, 2.450, 48.629, 34, 2.623, 49.433, 85, 
           3.195, 52.575, 33, 1.794, 21.995, 29, 1.812, 32.393, 46, 
           1.561, 13.352, 29, 2.556, 45.368, 32, 1.926, 48.571, 39, 
           3.089, 47.973, 37, 3.780, 47.435, 4, 3.683, 30.572, 1, 
           2.950, 63.461, 76, 2.344, 51.647, 87, 2.454, 48.666, 10, 
           3.685, 68.988, 7, 2.566, 25.318, 9, 3.467, 59.584, 5, 
           1.391, 36.848, 8, 1.495, 32.963, 26, 1.166, 26.183, 17, 
           1.499, 22.725, 87, 2.927, 55.305, 5, 2.519, 38.702, 33, 
           2.644, 52.027, 23, 1.232, 28.663, 33)

# Assign names to the vector for plotting (team names)
names(Team1) <- c("Atlanta_Braves", "New_York_Mets", "Philadelphia_Phillies", "Florida_Marlins", 
                  "Houston_Astros", "Chicago_Cubs", "St_Louis_Cardinals", "Cincinnati_Reds", 
                  "Milwaukee_Brewers", "Pittsburgh_Pirates", "San_Diego_Padres", "San_Francisco_Giants", 
                  "Colorado_Rockies", "Arizona_Diamondbacks", "New_York_Yankees", "Boston_Red_Sox", 
                  "Toronto_Blue_Jays", "Baltimore_Orioles", "Cleveland_Indians", "Chicago_White_Sox", 
                  "Kansas_City_Royals", "Minnesota_Twins", "Detroit_Tigers", "Texas_Rangers", 
                  "Anaheim_Angels", "Seattle_Mariners", "Oakland_Athletics", "Montreal_Expos", 
                  "Los_Angeles_Dodgers")
head(data)
# View the structure of the dataset
str(data)

# Identify the variable and plot the data
names(Team1)
plot(names(Team1), Team1, main = "Team Data", xlab = "Teams", ylab = "Values", type = "h")

# Obtain the mean and median
mean(Team1)
median(Team1)

# Plot histogram
hist(Team1, main = "Histogram of Team1 Data", xlab = "Values", col = "lightblue")

# Plot boxplot
boxplot(Team1, main = "Boxplot of Team1 Data", ylab = "Values", col = "lightgreen")


# Write a function
my_function <- function(x) {
  mean_x <- mean(x)
  median_x <- median(x)
  range_x <- range(x)
  return(list(mean = mean_x, median = median_x, range = range_x))
}

# Example usage with Team1
result <- my_function(Team1)
print(result)


# Plot and Quartile
quantile(Team1)

# Plot with quartiles
boxplot(Team1, main = "Boxplot with Quartiles", ylab = "Values", col = "lightyellow")


# Identify the mode
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

# Example usage with Team1
mode_result <- getmode(Team1)
print(mode_result)
